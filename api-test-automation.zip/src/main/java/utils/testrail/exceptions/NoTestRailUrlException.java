package utils.testrail.exceptions;

/**
 * @author Thanh Le
 * Created: 07 Jan 2020
 */
public class NoTestRailUrlException extends Exception {
    public NoTestRailUrlException(String message) {
        super(message);
    }
}
