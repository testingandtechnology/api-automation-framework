package utils.testrail.exceptions;

/**
 * @author Thanh Le
 */
public class ProjectNotFoundException extends Exception {
    public ProjectNotFoundException(String message) {
        super(message);
    }
}
