package utils.testrail.handlers;

/**
 * @author thle
 */
public enum TestResults {
    Passed,
    Blocked,
    Retest,
    Failed
}
